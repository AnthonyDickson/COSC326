#include "Node.h"

Node::Node(std::string value) {
    this->value = value;
    this->parent = nullptr;
}
